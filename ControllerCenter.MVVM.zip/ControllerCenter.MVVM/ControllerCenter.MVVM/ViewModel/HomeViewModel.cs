﻿using Microsoft.Practices.Prism.Commands;

namespace ControllerCenter.MVVM.ViewModel
{
    public class HomeViewModel : BaseViewModel
    {
    }
}
