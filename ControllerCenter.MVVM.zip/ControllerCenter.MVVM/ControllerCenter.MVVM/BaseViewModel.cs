﻿using Microsoft.Practices.Prism.ViewModel;
using System.ComponentModel;
using ControllerCenter.MVVM.Common;

namespace ControllerCenter.MVVM
{
    public class BaseViewModel : NotifyPropertyChanged 
    {
    }
}
