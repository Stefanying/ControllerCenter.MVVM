﻿using ControllerCenter.Model;

namespace ControllerCenter.IBLL
{
    public interface InterfaceParityCheckBitModelService : InterfaceBaseService<ParityCheckBitModel>
    {
    }
}
