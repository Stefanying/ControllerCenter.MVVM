﻿using ControllerCenter.Model;

namespace ControllerCenter.IBLL
{
    public interface InterfaceDataBitModelService : InterfaceBaseService<DataBitModel>
    {
    }
}
