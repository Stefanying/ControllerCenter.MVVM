﻿using ControllerCenter.Model;

namespace ControllerCenter.IBLL
{
    public interface InterfaceBaudRateModelService : InterfaceBaseService<BaudRateModel>
    {
    }
}
