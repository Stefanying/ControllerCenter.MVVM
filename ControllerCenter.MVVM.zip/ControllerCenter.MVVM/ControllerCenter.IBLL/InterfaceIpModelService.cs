﻿using ControllerCenter.Model;

namespace ControllerCenter.IBLL
{
    public interface InterfaceIpModelService : InterfaceBaseService<IpModel>
    {
    }
}
