﻿using ControllerCenter.Model;

namespace ControllerCenter.IBLL
{
    public interface InterfaceStopBitModelService : InterfaceBaseService<StopBitModel>
    {
    }
}
