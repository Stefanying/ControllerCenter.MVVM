﻿using ControllerCenter.Model;

namespace ControllerCenter.IDAL
{
    public interface InterfaceDataBitModelRepository : InterfaceBaseRepository<DataBitModel>
    {
    }
}
