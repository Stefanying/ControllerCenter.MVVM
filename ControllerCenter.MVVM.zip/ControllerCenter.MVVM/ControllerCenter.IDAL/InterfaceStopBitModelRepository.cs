﻿using ControllerCenter.Model;

namespace ControllerCenter.IDAL
{
    public interface InterfaceStopBitModelRepository : InterfaceBaseRepository<StopBitModel>
    {
    }
}
