﻿using ControllerCenter.Model;

namespace ControllerCenter.IDAL
{
    public interface InterfaceParityCheckBitModelRepository : InterfaceBaseRepository<ParityCheckBitModel>
    {
    }
}
