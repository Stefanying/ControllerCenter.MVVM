﻿using ControllerCenter.Model;

namespace ControllerCenter.IDAL
{
    public interface InterfaceCommPortModelRepository : InterfaceBaseRepository<CommPortModel>
    {
    }
}
