﻿using ControllerCenter.Model;

namespace ControllerCenter.IDAL
{
    public interface InterfaceIpModelRepository : InterfaceBaseRepository<IpModel>
    {
    }
}
