﻿using ControllerCenter.Model;

namespace ControllerCenter.IDAL
{
    public interface InterfaceBaudRateModelRepository : InterfaceBaseRepository<BaudRateModel>
    {
    }
}
