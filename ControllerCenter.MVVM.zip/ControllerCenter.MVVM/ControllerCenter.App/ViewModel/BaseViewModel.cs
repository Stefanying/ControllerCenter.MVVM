﻿using Microsoft.Practices.Prism.ViewModel;

namespace ControllerCenter.App.ViewModel
{
    public class BaseViewModel : NotificationObject
    {
    }
}
