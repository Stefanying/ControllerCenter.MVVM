﻿using ControllerCenter.Model;
using ControllerCenter.IDAL;

namespace ControllerCenter.DAL
{
    public class IpModelRepository : BaseRepository<IpModel>, InterfaceIpModelRepository
    {
    }
}
