﻿using ControllerCenter.Model;
using ControllerCenter.IDAL;

namespace ControllerCenter.DAL
{
    public class BaudRateModelRepository : BaseRepository<BaudRateModel>, InterfaceBaudRateModelRepository
    {
    }
}
