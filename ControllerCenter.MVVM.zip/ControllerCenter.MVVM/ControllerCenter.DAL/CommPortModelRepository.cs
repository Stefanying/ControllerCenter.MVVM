﻿using ControllerCenter.Model;
using ControllerCenter.IDAL;

namespace ControllerCenter.DAL
{
    public class CommPortModelRepository : BaseRepository<CommPortModel>, InterfaceCommPortModelRepository
    {
    }
}
