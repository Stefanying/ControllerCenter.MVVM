﻿using ControllerCenter.Model;
using ControllerCenter.IDAL;

namespace ControllerCenter.DAL
{
    public class ParityCheckBitModelRepository : BaseRepository<ParityCheckBitModel>, InterfaceParityCheckBitModelRepository
    {
    }
}
