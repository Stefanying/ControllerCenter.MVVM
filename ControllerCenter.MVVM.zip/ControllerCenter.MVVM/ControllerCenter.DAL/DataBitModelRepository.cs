﻿using ControllerCenter.Model;
using ControllerCenter.IDAL;

namespace ControllerCenter.DAL
{
    public class DataBitModelRepository : BaseRepository<DataBitModel>, InterfaceDataBitModelRepository
    {
    }
}
