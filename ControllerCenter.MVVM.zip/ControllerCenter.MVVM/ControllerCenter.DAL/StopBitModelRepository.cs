﻿using ControllerCenter.Model;
using ControllerCenter.IDAL;

namespace ControllerCenter.DAL
{
    public class StopBitModelRepository : BaseRepository<StopBitModel>, InterfaceStopBitModelRepository
    {
    }
}
